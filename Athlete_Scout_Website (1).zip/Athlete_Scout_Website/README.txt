ATHLETE SCOUT — Student Website Project

HOW TO OPEN
1. Download and extract the ZIP file.
2. Open the folder.
3. Double-click index.html. It opens in Chrome, Edge, or another browser.

FEATURES
- Dashboard with athlete totals and average rating
- Athlete profile list with search and sport filter
- Add athlete form
- Shortlist / remove from shortlist
- Side-by-side player comparison
- Scouting report library

TECHNOLOGY
HTML, CSS and JavaScript in one beginner-friendly file. No server or installation is required.

IMPORTANT
This is a front-end demonstration. New profiles and shortlist changes exist in the current page session only; there is no database or login system.
The sample performance figures and ratings are illustrative placeholders, not verified live sports statistics. Replace them with verified data for a formal submission.
